#ifndef ADD_INVERSE_H
#define ADD_INVERSE_H

void tableau_inverse();

void somme_matrice();

#endif